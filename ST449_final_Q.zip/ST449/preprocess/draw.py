from sklearn.model_selection import train_test_split
import torch
import matplotlib.pyplot as plt
import os
import numpy as np


# 'UCI HAR Dataset'
data_dir = "DataSet/time_classification_dataset/UCI_HAR_Dataset/raw/"
# '../../data/HAR'
output_dir = "/code/TS-GAC-main/GCC/preprocess/draw"

train_acc_x = np.loadtxt(f'{data_dir}/train/Inertial Signals/body_acc_x_train.txt')

def draw():
    colorbar = ['#76A0AD','#597C8B','#DABE84','#D9BDC3','#C4D0CC']
    for i in range(5):
        plt.plot(train_acc_x[i], color= colorbar[i])
    plt.savefig(output_dir + '/HAR_raw.png')




if __name__ == '__main__':
    dataset = 'UCI_HAR_Dataset'
    root_dir = "/DataSet/time_classification_dataset/"
    draw()